% readasalocs() - read 3-D location files saved using the ASA electrode 
%                    file format
% Usage:
%   >> CHANLOCS = readasalocs( filename );
%
% Inputs:
%   filename       - [string] file name (*.elc)
%
% Outputs:
%   CHANLOCS       - EEGLAB channel location data structure. 
%                    See help readlocs()
%
% Author: Ruud Kalis, ANT Enschede / Berlin 
%
% See also: readlocs(), readeetracklocs()

% Copyright (C) 2011 Ruud Kalis, ANT Enschede / Berlin
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

function chanlocs = readasalocs( filename )
    
    if nargin < 1
        help readeetraklocs;
        return;
    end;
    
    % read location file, leave out delimitors SPACE, TAB and :
    % ------------------
    locs  = loadtxt( filename, 'delim', [9, 32, 58]);
        
    % determine line numbers for keywords for file format
    % ---------------
    indices = [];
    inditem = [];
    for ind = 1:size(locs,1)
        if isstr(locs{ind,1}) 
            if strcmpi(locs{ind,1}, 'NumberPositions=')
                indices = [indices; ind];
                inditem = vertcat(inditem, mat2cell('NumberPositions='));
            end;
            if strcmpi(locs{ind,1}, 'Positions')
                indices = [indices; ind];
                inditem = vertcat(inditem, mat2cell('Positions'));
            end;
            if strcmpi(locs{ind,1}, 'Labels')
                indices = [indices; ind];
                inditem = vertcat(inditem, mat2cell('Labels'));
            end;
            if strcmpi(locs{ind,1}, 'UnitPosition')
                indices = [indices; ind];
                inditem = vertcat(inditem, mat2cell('UnitPosition'));
            end;            
            if strcmpi(locs{ind,1}, 'Positions2D')  % Positions2D is an optional item used in ASA ELC 
                indices = [indices; ind];      
                inditem = vertcat(inditem, mat2cell('Positions2D'));
            end;   
            if strcmpi(locs{ind,1}, 'HeadShapePoints')  % Positions2D is an optional tag used in ASA ELC 
                indices = [indices; ind]; 
                inditem = vertcat(inditem, mat2cell('HeadShapePoints')); 
            end; 
            if strcmpi(locs{ind,1}, 'NumberHeadShapePoints')  % Positions2D is an optional tag used in ASA ELC 
                indices = [indices; ind];
                inditem = vertcat(inditem, mat2cell('NumberHeadShapePoints'));
            end;             
            if strcmpi(locs{ind,1}, '#')  % Positions2D is an optional tag used in ASA ELC 
                indices = [indices; ind];
                inditem = vertcat(inditem, mat2cell('comment'));    
            end
        end;
    end;
    if isempty(indices) | isempty(inditem)
        error('Could not find ''Labels'' or ''Position'' tag in electrode file');
    end;
    
    % get indices of Positions and Labels
    % -------------
    positionIndex = find(strcmp(inditem, 'Positions'));
    labelsIndex = find(strcmp(inditem, 'Labels'));
   
    % default columns for position coordinates are columns 2-4
    positionCols = [2:4];
    % labels before position coordinates are optional, check for this case
    if (isempty(cell2mat(locs(indices(positionIndex)+1,4))))
        positionCols = [1:3];
    end
    
    % Positions matrix is at the end of file
    if (positionIndex == length(indices))
        positions = locs(indices(positionIndex)+1:end,positionCols);
    else % Positions matrix is somewhere at the beginning or middle of file 
        positions = locs(indices(positionIndex)+1:indices(positionIndex+1)-1,positionCols);
    end
    
    % get labels    
    % -------------
    % labels are somewhere at the begining or middle of file
    if (labelsIndex < length(inditem))
        labelsMat = locs(indices(labelsIndex) + 1:indices(labelsIndex + 1) - 1,:);
        labels = [];
        % this loop takes care of the fact that line breaks are also
        % delimiters in the ELC file format.        
        for irow = 1:size(labelsMat,1)
            for icol = 1:size(labelsMat,2)
                if(iscellstr(labelsMat(irow, icol)) && ~(strcmpi(labelsMat(irow, icol), 'GND')))
                    labels = [labels, labelsMat(irow, icol)];
                end
                % case where numbers are used as labels
                if ( ~isempty(cell2mat(labelsMat(irow, icol))) && isnumeric(cell2mat(labelsMat(irow, icol))))
                    labels = [labels, labelsMat(irow, icol)];    
                end       
            end
        end
    else % labels are at the end of file
        labelsMat = locs(indices(labelsIndex) + 1:end,:);
        labels = [];
        % this loop takes care of the fact that line breaks are also
        % delimiters in the ELC file format.
        for irow = 1:size(labelsMat,1)
            for icol = 1:size(labelsMat,2)
                if(iscellstr(labelsMat(irow, icol)) && ~(strcmpi(labelsMat(irow, icol), 'GND')))
                    labels = [labels, labelsMat(irow,icol)];
                end
                % case where numbers are used as labels
                if ( ~isempty(cell2mat(labelsMat(irow, icol))) && isnumeric(cell2mat(labelsMat(irow, icol))))
                    labels = [labels, labelsMat(irow, icol)];    
                end                       
            end
        end
    end
        
    % create structure
    % ----------------
    for index = 1:length(labels)
        chanlocs(index).labels = labels{index};
        chanlocs(index).X      = positions{index,1};
        chanlocs(index).Y      = positions{index,2};
        chanlocs(index).Z      = positions{index,3};
    end;
        
    chanlocs = convertlocs(chanlocs, 'cart2all');
