function penum(varargin)
%PENUM Pseudo Enumeration
%  PENUM E_1 E_2 ... E_n defines an enumeration with identifiers
%  E_1, E_2,... E_n. After defining the enumeration the expression
%  E_k evaluates to k. Each E_k must be a legal MATLAB function
%  name. Enumerations have the same case-sensitivity as function
%  names.
%
%  PENUM -type CLASS E_1 ... E_n defines each enum E_k to be of the
%  specified class. CLASS can be any numeric class name (e.g. 'double',
%  'float', 'uint8') or 'char'. If CLASS is 'char' then E_k evaluates to
%  the identifier as a string. The default class is double.  
%
%  PENUM -unique E_1 ... E_n defines each enum E_k to be a finite value
%  computed only from the characters in E_k. Unique enums are very small 
%  positive numbers so they can be treated as zero in computations.
%  Non-floating point types are not allowed for unique enums.
%
%  PENUM -from M E_1 ... E_n defines each E_k as k+M-1.
%
%  PENUM -name NAME E_1 ... E_n gives the enumeration a string NAME to be
%  used in DISPE or to clear the definition. After defining the
%  enumeration the string NAME evaluates to the cell array of identifiers
%  E_1...E_n. 
%
%  PENUM -silent ... supress warnings when redefining functions or enums.
%
%  PENUM -clear removes all enumeration definitions.
%  PENUM -clear NAME removes the enumeration named NAME.
%
%  Examples:
%    penum -name states AL FL MA NY WY
%    penum -name months Jan Feb Mar Apr
%    snow = rand(length(states),length(months));
%    snow([MA NY WY], Jan:Feb) = 3;
%    penum -unique -silent NoData
%    snow(FL,:) = NoData;
%    dispe(snow, states, months)
%    plot(snow');
%    set(gca, 'xtick',1:length(months),'xticklabel', months);
%    legend(states);
%
%  See also DISPE

%  Note: if MATLAB exists without running the finish.m function created by this
%  function then you should go into the tempdir and delete the files in the
%  directory ['penum' pid] where pid is the process id of the MATLAB session
%  that created the enumerations.

%  Copyright 2003-2009 The MathWorks, Inc.

% TODO:
%  split directories for easier searching
%  think of a way to get non-floating point unique enums (uint8 NoData)
%  allow step-size > 1 between enums?


% defaults
vclass = 'double';
vunique = logical(0);
initial = 1;
name = '';
silent = logical(0);

% process input options
n = 1;
while (n <= nargin) & ischar(varargin{n}) & (varargin{n}(1) == '-')
  switch varargin{n}(2)
   case 't'
    n = n+1;
    vclass = varargin{n};
    checkUniqueType(vclass,vunique)
   case 'u'
    vunique = logical(1);
    checkUniqueType(vclass,vunique)
   case 'f'
    n = n+1;
    if ischar(varargin{n})
      initial = eval(varargin{n});
    else
      initial = floor(double(varargin{n}));
    end
   case 'n'
    n = n+1;
    name = varargin{n};
   case 'c'
    if nargin > n
      clearEnum(varargin{n+1});
    else
      clearEnumAll;
    end
    return;
   case 's'
    silent = logical(1);
  end
  n = n+1;
end

vals = varargin(n:end);
path = getEnumPath;
if ~isempty(vals)
  initial = initial-1;

  % process each enumeration value
  for k=1:length(vals);
    if strcmp(vclass,'char')
      value = vals{k};
      writeEnum(path,vals{k},vclass,value,vunique,silent);
    else
      if vunique
        value = computeUnique(vclass,vals{k});
      else
        value = k+initial;
      end
      writeEnum(path,vals{k},vclass,value,vunique,silent);
    end
  end

end

if ~isempty(name)
  writeName(path,name,vals,silent);
end

% write the file for enum 's' with value 'value'
% and class 'cls' to directory 'path'
function writeEnum(path,s,cls,value,vunique,silent)
try
  fname = fullfile(path,[s '.m']);
  if ~silent
    if exist(fname,'file')
      warning(['Redefining existing enumeration value ''' s '''.'])
    else
      ex = exist(s);
      if ex > 1 & ex ~= 7
        warning(['Redefining existing function ''' s '''.'])
      end
    end
  end
  fid = fopen(fname,'w');
  fprintf(fid,['function x=' s '\n']);
  fprintf(fid,['%%' s ' Enumeration value\n\n']);
  if vunique
    fprintf(fid,'%%unique\n');
  end
  fprintf(fid,'persistent value;\n');
  fprintf(fid,'if isempty(value)\n');
  if any(strcmp(cls,{'double','single'}))
    [f,e] = log2(value);
    if (e > 0) % is an integer enum
      if strcmp(cls,'double')
	fprintf(fid,'  value = %d;\n',value);
      else
	fprintf(fid,'  value = single(%d);\n',value);
      end
    else % is a tiny unique
      fprintf(fid,'  f = sscanf(''%1.16f'',''%%f'');\n',f);
      fprintf(fid,['  e = ' num2str(e) ';\n']);
      fprintf(fid,'  value = %s(pow2(f,e));\n',cls);
    end
  elseif strcmp(cls,'char')
    fprintf(fid,['  value = ''' value ''';\n']);
  else
    fprintf(fid,'  value = %s(%d);\n',cls,value);
  end
  fprintf(fid,'end\n');
  fprintf(fid,'x = value;\n');
  fclose(fid);
end

% write enumeration named 's' with cell array of
% strings 'names' to directory 'path'
function writeName(path,s,names,silent)
try
  fname = fullfile(path,[s '.m']);
  if ~silent
    if exist(fname,'file')
      warning(['Redefining existing enumeration value ''' s '''.'])
    else
      ex = exist(s);
      if ex > 1 & ex ~= 7
        warning(['Redefining existing function ''' s '''.'])
      end
    end
  end
  fid = fopen(fname,'w');
  fprintf(fid,['function x=' s '\n']);
  fprintf(fid,['%%' s ' Enumeration name\n\n']);
  str = sprintf('''%s'',',names{:});
  str(end) = [];
  fprintf(fid,['x={' str '};\n']);
  fclose(fid);
end

% delete all the files associated with enumeration 'name'
function clearEnum(name)
try
  ev = eval(name);
  path = getEnumPath;
  for k=1:length(ev)
    ename = ev{k};
    delete(fullfile(path,[ename '.m']));
  end
  delete(fullfile(path,[name '.m']));
end

% delete all enumeration files but not the temp directory
function clearEnumAll
try
  path = getEnumPath;
  ev = dir(path);
  names = {ev.name};
  for k=1:length(names)
    ename = names{k};
    if any(strcmp(ename,{'.','..','finish.m'}))
      continue;
    end
    delete(fullfile(path,ename));
  end
end

% get path to directory in which to store enumerations
function path = getEnumPath
pid = system_dependent('getpid'); % undocumented, unsupported
dirname = ['penum' num2str(pid)];
path = fullfile(tempdir,dirname);
if ~exist(path,'dir')
  [ok,msg] = mkdir(tempdir,dirname);
  if ~ok
    error(['Cannot create enumeration directory: ' msg]);
  end
  addpath(path);
end
finishname = fullfile(path,'finish.m');
if ~exist(finishname,'file')
  writeFinish(path,finishname);
end

% compute the unique code for a given string 'str'
% and return value as class 'vclass', should be
% double or single.
function x = computeUnique(vclass,str)
x = 0;
for k=length(str):-1:1 % make tail of identifier significant
  if str(k) <= 'Z' & str(k) >= 'A'
    dig = str(k)-'A';
  elseif str(k) <= 'z' & str(k) >= 'a'
    dig = str(k)-'a'+26;
  elseif str(k) <= '9' & str(k) >= '0'
    dig = str(k)-'0'+2*26;
  else % should just be _ left
    dig = 63;
  end
  x = x*64 + dig;
end
[f,e]=log2(x);
if strcmp(vclass,'double')
  x = pow2(f,-900);
else
  x = pow2(f,-120);
end

% write the finish.m function to clear up enumerations
function writeFinish(path,finishname)
fid = fopen(finishname,'w');
fprintf(fid,'function finish\n');

% delete the finish function and the temp directory
fprintf(fid,'rmpath %s\n',path);
if isunix
  fprintf(fid,'unix(''rm -rf %s'');\n',path);
else
  fprintf(fid,'dos(''rmdir /S /Q %s'');\n',path);
end
fprintf(fid,'clear functions\n');

% run any other finish function that might be on the path
fprintf(fid,'try finish; end\n');

fclose(fid);

% make sure user isn't trying to use a non-floating point
% type with unique enumeration values
function checkUniqueType(vclass,vunique)
if vunique & ~any(strcmp(vclass,{'double','single'}))
  error('Unique enumerations must be floating point types');
end
