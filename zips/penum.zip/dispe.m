function dispe(x,varargin)
%DISPE Display with enumerations
%  DISPE(X) displays array X with unique enumeration names printed
%  in place of the unique enumeration values.
%
%  DISPE(X,NAMES_1,NAMES_2,...,NAMES_d) where d is the number of
%  dimenions of X and NAMES_k is either empty or a cell array of strings
%  specifiying the header names or enumeration names for that slice or
%  dimension. For example, if NAMES_1={[],'states'} and there exists an
%  enumeration named 'states' then the second row of X will be displayed
%  with the states names instead of numeric values. If NAMES_1=states
%  then the states names will be used as row headers.
%
%  Example:
%    penum -unique -silent NoData
%    penum -name GeoLoc UK US
%    x = [10 US; NoData US; 20 UK];
%    dispe(x,[],{'','GeoLoc'})
%
%  See also PENUM

%  Copyright 2003-2009 The MathWorks, Inc.

% TODO:
%  handle n-d arrays
%  format like built-in disp (spacing, precision, etc)
%  efficiency
%  think of API to specify both row/col enums and row/col headers

path = getEnumPath;
if ~exist(path,'dir') | ~isnumeric(x)
  disp(x);
  return;
end

dims = length(size(x));
if dims == 2
  dispMatrix(x,path,varargin{:});
else
  disp(x); % should do something better here
end

% display a matrix with given row and column information
function dispMatrix(x,path,rows,cols)
if nargin < 4, cols = {}; end
if nargin < 3, rows = {}; end
if ~isempty(cols) & ~isa(cols,'cell')
  error('Column list must be a cell array.');
end
if ~isempty(rows) & ~isa(rows,'cell')
  error('Row list must be a cell array.');
end
colsAreTypes = 0;
for k=1:length(cols)
  if exist(fullfile(path,[cols{k} '.m']),'file')
    if isa(feval(cols{k}),'cell')
      colsAreTypes = 1;
      break;
    end
  end
end
rowsAreTypes = 0;
for k=1:length(rows)
  if exist(fullfile(path,[rows{k} '.m']),'file')
    if isa(feval(rows{k}),'cell')
      rowsAreTypes = 1;
      break;
    end
  end
end

s = size(x);
N = length(cols);
M = length(rows);
uniques = findUniques(path);
if ~colsAreTypes & ~isempty(cols)
  if ~rowsAreTypes & ~isempty(rows)
    line = sprintf('%10s','');
  else
    line = [];
  end
  for n = 1:min(N,s(2))
    line = [line sprintf('%10s',cols{n})];
  end
  disp(line)
end
for m=1:s(1)
  if ~rowsAreTypes & ~isempty(rows)
    if m > M
      line = sprintf('%10s','');
    else
      line = sprintf('%10s',rows{m});
    end
  else
    line = [];
  end
  for n = 1:s(2)
    val = x(m,n);
    enums = uniques;
    if colsAreTypes & ~isempty(cols) & n <= N & ~isempty(cols{n})
      try
        res = feval(cols{n});
        enums = {enums{:}, res{:}};
      end
    end
    if rowsAreTypes & ~isempty(rows) & m <= M & ~isempty(rows{m})
      try
        res = feval(rows{m});
        enums = {enums{:}, res{:}};
      end
    end
    str = dispNum(double(val),enums);
    str = sprintf('%10s',str);
    line = [line str];
  end
  disp(line);
end

% convert a value into a string using the cell array 
% 'enums' of possible enumeration names
function str = dispNum(val,enums)
for k = 1:length(enums)
  if isequal(val,feval(enums{k}))
    str = enums{k};
    return;
  end
end
str = num2str(val);

function u = findUniques(path)
% brute force approach
u = {};
ev = dir(path);
names = {ev.name};
for k=1:length(names)
  ename = names{k};
  if any(strcmp(ename,{'.','..','finish.m'}))
    continue;
  end
  fid = fopen(fullfile(path,ename),'r');
  for l=1:4;
    w=fgetl(fid);
  end
  fclose(fid);
  if strcmp(w,'%unique')
    u{end+1} = ename(1:end-2);
  end
end

% get path to directory in which to store enumerations
function path = getEnumPath
pid = system_dependent('getpid'); % undocumented, unsupported
dirname = ['penum' num2str(pid)];
path = fullfile(tempdir,dirname);
